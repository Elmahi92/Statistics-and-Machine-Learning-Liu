# 732A90_Computational_Statistics

This repository contains all my labs with Phillip for the course Computational-Statistics.
